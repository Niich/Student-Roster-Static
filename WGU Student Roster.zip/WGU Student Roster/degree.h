#ifndef DEGREE_H
#define DEGREE_H

enum degree {
   SOFTWARE = 0,
   SECURITY = 1,
   NETWORKING = 2
};

#endif